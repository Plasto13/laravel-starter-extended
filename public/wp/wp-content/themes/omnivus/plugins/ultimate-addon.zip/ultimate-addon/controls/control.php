<?php
class Ultimate_Control{
	
}